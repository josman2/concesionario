package com.example.concesionario;

import androidx.appcompat.app.AppCompatActivity; // Importa la clase base de las actividades de Android.
import android.content.ContentValues; // Importa ContentValues para manejar datos en la base de datos.
import android.content.Intent; // Importa Intent para realizar transiciones entre actividades.
import android.database.Cursor; // Importa Cursor para trabajar con resultados de consultas en la base de datos.
import android.database.sqlite.SQLiteDatabase; // Importa SQLiteDatabase para gestionar la base de datos.
import android.os.Bundle; // Importa Bundle para gestionar el estado de la actividad.
import android.view.View; // Importa View para manejar eventos de la interfaz de usuario.
import android.widget.CheckBox; // Importa CheckBox para trabajar con elementos de casilla de verificación.
import android.widget.EditText; // Importa EditText para trabajar con campos de texto.
import android.widget.Toast; // Importa Toast para mostrar mensajes emergentes.

public class ClienteActivity extends AppCompatActivity {

    EditText jetidentificacion, jetnombre, jetcorreo; // Declaración de EditText para la identificación, nombre y correo.
    CheckBox jcbactivo; // Declaración de un CheckBox para el estado activo/inactivo.
    String identificacion, nombre, correo; // Variables para almacenar los valores ingresados.
    ClsOpenHelper admin = new ClsOpenHelper(this, "Concesionario.db", null, 1); // Instancia de la clase ClsOpenHelper que ayuda a gestionar la base de datos.
    long respuesta; // Variable para almacenar la respuesta de operaciones en la base de datos.
    Byte sw; // Variable para controlar el flujo de operaciones.
    Byte activacion; // Variable para controlar el estado activo/inactivo de un cliente.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente);

        // Ocultar la barra de título por defecto y asociar objetos Java con objetos XML.
        getSupportActionBar().hide();
        jetidentificacion = findViewById(R.id.etidentificacion);
        jetnombre = findViewById(R.id.etnombre);
        jetcorreo = findViewById(R.id.etcorreo);
        jcbactivo = findViewById(R.id.cbactivo);
        sw = 0;
        activacion = 0;
    }

    // Método para guardar o actualizar un registro en la base de datos.
    public void Guardar(View view) {
        identificacion = jetidentificacion.getText().toString();
        nombre = jetnombre.getText().toString();
        correo = jetcorreo.getText().toString();
        if (identificacion.isEmpty() || nombre.isEmpty() || correo.isEmpty()) {
            Toast.makeText(this, "Todos los datos son requeridos", Toast.LENGTH_SHORT).show();
            jetidentificacion.requestFocus();
        } else {
            SQLiteDatabase db = admin.getWritableDatabase(); // Obtiene una instancia de base de datos en modo escritura.
            ContentValues registro = new ContentValues(); // Objeto ContentValues para almacenar datos a ser insertados o actualizados.

            // Agregar valores a registro.
            registro.put("identificacion", identificacion);
            registro.put("nombre", nombre);
            registro.put("correo", correo);

            if (sw == 0) { // Si sw es 0, se inserta un nuevo registro.
                respuesta = db.insert("TblCliente", null, registro); // Insertar registro en la tabla "TblCliente".
                if (respuesta == 0) {
                    Toast.makeText(this, "Error guardando registro", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Registro guardado", Toast.LENGTH_SHORT).show();
                    Limpiar_campos(); // Limpiar campos después de una operación exitosa.
                }
            } else { // Si sw no es 0, se actualiza un registro existente.
                respuesta = db.update("TblCliente", registro, "identificacion='" + identificacion + "'", null); // Actualizar registro en la tabla "TblCliente".
                sw = 0;
                if (respuesta == 0) {
                    Toast.makeText(this, "Error modificando registro", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Registro modificado", Toast.LENGTH_SHORT).show();
                    Limpiar_campos();
                }
            }
            db.close(); // Cerrar la conexión de la base de datos.
        }
    } // Fin del método Guardar

    // Método para activar o desactivar un cliente.
    public void Anular(View view) {
        if (sw == 1) { // Si sw es 1, se permite la activación o desactivación.
            sw = 0;
            SQLiteDatabase db = admin.getWritableDatabase(); // Obtener una instancia de la base de datos en modo escritura.
            ContentValues registro = new ContentValues(); // Objeto ContentValues para almacenar datos a ser actualizados.

            if (activacion == 1) { // Si activación es 1, el cliente está activo y se desactivará.
                registro.put("activo", "No");
                respuesta = db.update("TblCliente", registro, "identificacion='" + identificacion + "'", null);
                if (respuesta > 0) {
                    Toast.makeText(this, "Cliente desactivado", Toast.LENGTH_SHORT).show();
                    activacion = 0;
                    Limpiar_campos();
                } else {
                    Toast.makeText(this, "Error desactivando Cliente", Toast.LENGTH_SHORT).show();
                    Limpiar_campos();
                }
            } else { // Si activación no es 1, el cliente está inactivo y se activará.
                registro.put("activo", "Si");
                respuesta = db.update("TblCliente", registro, "identificacion='" + identificacion + "'", null);
                if (respuesta > 0) {
                    Toast.makeText(this, "Cliente activado", Toast.LENGTH_SHORT).show();
                    activacion = 1;
                    Limpiar_campos();
                } else {
                    Toast.makeText(this, "Error activando cliente", Toast.LENGTH_SHORT).show();
                    Limpiar_campos();
                }
            }
            db.close(); // Cerrar la conexión de la base de datos.
        } else {
            Toast.makeText(this, "Debe primero realizar consultar", Toast.LENGTH_SHORT).show();
        }
    }

    // Método para consultar un cliente en la base de datos.
    public void Consultar(View view) {
        identificacion = jetidentificacion.getText().toString();
        if (identificacion.isEmpty()) {
            Toast.makeText(this, "Identificacion requerida para la búsqueda", Toast.LENGTH_SHORT).show();
            jetidentificacion.requestFocus();
        } else {
            SQLiteDatabase db = admin.getReadableDatabase(); // Obtener una instancia de la base de datos en modo lectura.
            Cursor fila = db.rawQuery("select * from TblCliente where identificacion='" + identificacion + "'", null); // Consultar la tabla "TblCliente".

            if (fila.moveToNext()) { // Si se encuentra un registro.
                sw = 1;
                if (fila.getString(3).equals("No")) { // Si el cliente está inactivo.
                    Toast.makeText(this, "Cliente existe, pero está anulado", Toast.LENGTH_SHORT).show();
                    activacion = 0;
                } else {
                    jetnombre.setText(fila.getString(1));
                    jetcorreo.setText(fila.getString(2));
                    jcbactivo.setChecked(true);
                    activacion = 1;
                }
            } else {
                Toast.makeText(this, "Cliente no registrado", Toast.LENGTH_SHORT).show();
            }
            db.close(); // Cerrar la conexión de la base de datos.
        }
    } // Fin del método Consultar

    // Método para regresar a la actividad principal.
    public void Regresar(View view) {
        Intent intmain = new Intent(this, MainActivity.class);
        startActivity(intmain);
    }

    // Método para cancelar la operación actual y limpiar los campos.
    public void Cancelar(View view) {
        Limpiar_campos();
    }

    // Método para limpiar los campos de entrada y restablecer valores.
    private void Limpiar_campos() {
        jetidentificacion.setText("");
        jetnombre.setText("");
        jetcorreo.setText("");
        jcbactivo.setChecked(false);
        jetidentificacion.requestFocus();
        sw = 0;
        activacion = 0;
    }
}
