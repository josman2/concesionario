package com.example.concesionario;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class VentaActivity extends AppCompatActivity {

    // Declaración de variables miembro
    EditText jetcodigo, jetfecha, jetidentificacion, jetplaca;
    TextView jtvnombre, jtvcorreo, jtvmodelo, jtvmarca;
    CheckBox jcbactivoventa;
    Button jbtanular;

    String codigo, fecha;
    String identificacion, nombre, correo;
    String placa, marca, modelo;

    long respuesta;
    Byte sw;
    Byte activacion;

    ClsOpenHelper admin = new ClsOpenHelper(this, "Concesionario.db", null, 1);

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_venta); // Establece el diseño de la actividad VentaActivity.

        // Ocultar la barra de título por defecto y asociar objetos Java con objetos XML.
        getSupportActionBar().hide();
        jetcodigo = findViewById(R.id.etcodigo);
        jetfecha = findViewById(R.id.etfecha);
        jetidentificacion = findViewById(R.id.etidentificacion);
        jetplaca = findViewById(R.id.etplaca);
        jtvnombre = findViewById(R.id.tvnombre);
        jtvcorreo = findViewById(R.id.tvcorreo);
      //  jtvmodelo = findViewById(R.id.tvmodelo);
     //   jtvmarca = findViewById(R.id.tvmarca);
        jcbactivoventa = findViewById(R.id.cbactivoventa);
        jbtanular = findViewById(R.id.btanular);
        sw = 0;
        activacion = 0;
    }

    public void Guardar(View view) {
        // Obtiene los valores de los campos de entrada
        codigo = jetcodigo.getText().toString();
        fecha = jetfecha.getText().toString();
        identificacion = jetidentificacion.getText().toString();
        nombre = jtvnombre.getText().toString();
        correo = jtvcorreo.getText().toString();
        placa = jetplaca.getText().toString();
      /*  modelo = jtvmodelo.getText().toString();
        marca = jtvmarca.getText().toString();*/

        // Verifica si algún campo está vacío
         if (codigo.isEmpty() || fecha.isEmpty() ||
                identificacion.isEmpty() || nombre.isEmpty() || correo.isEmpty() ||
                placa.isEmpty()) {
            Toast.makeText(this, "Todos los datos son requeridos", Toast.LENGTH_SHORT).show();
            jetcodigo.requestFocus();
        } else {
            SQLiteDatabase bd = admin.getReadableDatabase();
            Cursor fila = bd.rawQuery("select * from TblVenta where placa ='" + placa + "' and activo = 'Si' ", null);
            if (fila.moveToNext()) {
                    Toast.makeText(this, "No se puede guardar, El Vehiculo esta vendido", Toast.LENGTH_SHORT).show();
                    Limpiar_campos();
            }
           else {
                SQLiteDatabase db = admin.getWritableDatabase();
                ContentValues registro = new ContentValues();
                registro.put("codigo", codigo);
                registro.put("fecha", fecha);
                registro.put("identificacion", identificacion);
                registro.put("placa", placa);
                respuesta = db.insert("TblVenta", null, registro);
                if (respuesta == 0) {
                        Toast.makeText(this, "Error guardando registro", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "REGISTRO GUARDADO", Toast.LENGTH_SHORT).show();
                        Desactivar(placa);
                        Limpiar_campos();
                    }
               db.close();
                }
            }
    }//fin metodo guardar

    public void ConsultarVenta(View view) {
        codigo = jetcodigo.getText().toString();
        if (codigo.isEmpty()) {
            Toast.makeText(this, "Codigo de venta requerido para la BUSQUEDA", Toast.LENGTH_SHORT).show();
            jetcodigo.requestFocus();
        } else {
            SQLiteDatabase db = admin.getReadableDatabase();
            Cursor fila = db.rawQuery("select * from TblVenta where codigo ='" + codigo + "'", null);
            if (fila.moveToNext()) {
                sw = 1;
                if (fila.getString(4).equals("No")) {
                    Toast.makeText(this, "Venta existe, pero esta anulada", Toast.LENGTH_SHORT).show();
                    activacion = 0;
                } else {
                    jetfecha.setText(fila.getString(1));
                    jetidentificacion.setText(fila.getString(2));
                    jetplaca.setText(fila.getString(3));
                    jcbactivoventa.setChecked(true);
                    Toast.makeText(this, "Venta existe", Toast.LENGTH_SHORT).show();
                    ConsultarVehiculo();
                    ConsultarCliente();
                    activacion = 1;
                }
            } else {
                Toast.makeText(this, "Venta no registrada", Toast.LENGTH_SHORT).show();
            }
            db.close();
        }
    } // fin metodo consultar venta

    public void ConsultarCliente(View view) {
        ConsultarCliente();
    }

    public void ConsultarCliente() {
        identificacion = jetidentificacion.getText().toString();
        if (identificacion.isEmpty()) {
            Toast.makeText(this, "Identificacion requerida para la busqueda", Toast.LENGTH_SHORT).show();
            jetidentificacion.requestFocus();
        } else {
            SQLiteDatabase db = admin.getReadableDatabase();
            Cursor fila = db.rawQuery("select * from TblCliente where identificacion='" + identificacion + "'", null);
            if (fila.moveToNext()) {
                if (fila.getString(3).equals("No")) {
                    Toast.makeText(this, "Cliente existe pero esta desactivado", Toast.LENGTH_SHORT).show();
                } else {
                    jtvnombre.setText(fila.getString(1));
                    jtvcorreo.setText(fila.getString(2));
                    Toast.makeText(this, "Cliente existe", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Cliente no esta registrado", Toast.LENGTH_SHORT).show();
            }
            db.close();
        }
    }//Metodo consultar cliente

    public void ConsultarVehiculo(View view) {
        ConsultarVehiculo();
    }

    public void ConsultarVehiculo() {
        placa = jetplaca.getText().toString();
        if (placa.isEmpty()) {
            Toast.makeText(this, "Placa requerida para la busqueda", Toast.LENGTH_SHORT).show();
            jetplaca.requestFocus();
        } else {
            SQLiteDatabase db = admin.getReadableDatabase();
            Cursor fila = db.rawQuery("select * from TblVehiculo where placa ='" + placa + "'", null);
            if (fila.moveToNext()) {
                if (fila.getString(3).equals("No")) {
                    Toast.makeText(this, "Vehiculo existe, pero esta desactivado", Toast.LENGTH_SHORT).show();
                    jtvmodelo.setText(fila.getString(1));
                    jtvmarca.setText(fila.getString(2));
                    activacion = 0;
                } else {
                    jtvmodelo.setText(fila.getString(0)); // Índice 0 para la columna 'modelo'
                    jtvmarca.setText(fila.getString(1));  // Índice 1 para la columna 'marca'

                    activacion = 1;
                    Toast.makeText(this, "Vehiculo existe", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Vehiculo no registrado", Toast.LENGTH_SHORT).show();
            }
            db.close();
        }
    } // fin metodo consultar vehiculo

    private void Limpiar_campos() {
        jetcodigo.setText("");
        jetfecha.setText("");
        jetidentificacion.setText("");
        jetplaca.setText("");
        jtvnombre.setText("");
        jtvcorreo.setText("");
        jcbactivoventa.setText("");
        jcbactivoventa.setChecked(false);
        jetcodigo.requestFocus();
        sw = 0;
        activacion = 0;
    }

    public void Regresar(View view) {
        Intent intmain = new Intent(this, MainActivity.class);
        startActivity(intmain);
    }

    public void Cancelar(View view) {
        Limpiar_campos();
    }// Fin Metodo limpiar

    public void Anular(View view) {
        if (sw == 1) {
            sw = 0;
            SQLiteDatabase db = admin.getWritableDatabase();
            ContentValues registro = new ContentValues();

            if (activacion == 1) {  // desactivar
                registro.put("activo", "No");
                respuesta = db.update("TblVenta", registro, "codigo='" + codigo + "'", null);
                if (respuesta > 0) {
                    Toast.makeText(this, "Venta desactivada", Toast.LENGTH_SHORT).show();
                    activacion = 0;
                    Activar(placa);
                    Limpiar_campos();
                } else {
                    Toast.makeText(this, "Error desactivando venta", Toast.LENGTH_SHORT).show();
                    Limpiar_campos();
                }
            }
            db.close();
        } else {
            Toast.makeText(this, "Debe primero realizar consultar", Toast.LENGTH_SHORT).show();
        }
    }

    public void Desactivar(String placa) { // activar vehiculo cuando desactiva la venta
        SQLiteDatabase db = admin.getWritableDatabase();
        ContentValues registro = new ContentValues();

        registro.put("activo", "No");
        respuesta = db.update("TblVehiculo", registro, "placa='" + placa + "'", null);
        if (respuesta > 0) {
            Limpiar_campos();
        }
        db.close();
    }

    public void Activar(String placa) { //desactivar vehiculo cuando guarda la venta
        SQLiteDatabase db = admin.getWritableDatabase();
        ContentValues registro = new ContentValues();

        registro.put("activo", "Si");
        respuesta = db.update("TblVehiculo", registro, "placa='" + placa + "'", null);
        if (respuesta > 0) {
            Limpiar_campos();
        }
        db.close();
    }
}
